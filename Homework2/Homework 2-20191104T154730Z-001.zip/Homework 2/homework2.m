%% Homework 2 - Digital and Optimal Control
%Henrik Lucande
%724140
close all
clear all
m = 1000;
b = 100;
K_p = 1050;
K_i = 638;


 